# Black History Month Project

A Pen created on CodePen.io. Original URL: [https://codepen.io/TonyStank7/pen/BaOKbZo](https://codepen.io/TonyStank7/pen/BaOKbZo).

